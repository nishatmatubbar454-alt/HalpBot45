import { 
  getSettings, 
  saveOrUpdateUser, 
  addActivityLog, 
  getUserById 
} from "./firebaseService.js";
import { generateAiReply } from "./geminiService.js";

interface TelegramUser {
  id: number;
  is_bot: boolean;
  first_name: string;
  last_name?: string;
  username?: string;
}

interface TelegramChat {
  id: number;
  type: string;
  first_name?: string;
  last_name?: string;
  username?: string;
}

interface TelegramMessage {
  message_id: number;
  from?: TelegramUser;
  chat: TelegramChat;
  date: number;
  text?: string;
  photo?: Array<{ file_id: string }>;
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
  callback_query?: {
    id: string;
    from: TelegramUser;
    message?: TelegramMessage;
    data?: string;
  };
}

class TelegramBotEngine {
  private isRunning: boolean = false;
  private pollOffset: number = 0;
  private abortController: AbortController | null = null;
  private botInfo: any = null;
  private lastError: string | null = null;
  private activePollingPromise: Promise<void> | null = null;
  private lastPollSuccess: number = Date.now();
  private watchdogInterval: NodeJS.Timeout | null = null;

  public async getStatus() {
    let webhookInfo: any = null;
    try {
      const whRes = await this.getWebhookInfo();
      if (whRes.ok) {
        webhookInfo = whRes.result;
      }
    } catch {}

    return {
      isRunning: this.isRunning,
      botInfo: this.botInfo,
      lastError: this.lastError,
      pollOffset: this.pollOffset,
      lastPollSuccess: this.lastPollSuccess,
      uptimeSeconds: Math.floor(process.uptime()),
      webhook: webhookInfo
    };
  }

  public async getWebhookInfo(): Promise<{ ok: boolean; result?: any; error?: string }> {
    const settings = await getSettings();
    if (!settings.botToken) return { ok: false, error: 'Bot token missing' };
    try {
      const res = await fetch(`https://api.telegram.org/bot${settings.botToken}/getWebhookInfo`);
      const data = await res.json();
      return data;
    } catch (e: any) {
      return { ok: false, error: e.message };
    }
  }

  public async setWebhook(url: string): Promise<{ ok: boolean; description?: string; error?: string }> {
    const settings = await getSettings();
    if (!settings.botToken) return { ok: false, error: 'Bot token missing' };

    // Stop polling loop if active to prevent 409 conflict
    if (this.isRunning) {
      this.isRunning = false;
      if (this.abortController) {
        this.abortController.abort();
        this.abortController = null;
      }
    }

    try {
      const res = await fetch(`https://api.telegram.org/bot${settings.botToken}/setWebhook?url=${encodeURIComponent(url)}&drop_pending_updates=false`);
      const data = await res.json();
      if (data.ok) {
        await addActivityLog({
          type: 'system',
          message: `Telegram Webhook 24/7 activated: ${url}`
        }).catch(() => {});
      }
      return data;
    } catch (e: any) {
      return { ok: false, error: e.message };
    }
  }

  public async deleteWebhook(): Promise<{ ok: boolean; description?: string; error?: string }> {
    const settings = await getSettings();
    if (!settings.botToken) return { ok: false, error: 'Bot token missing' };
    try {
      const res = await fetch(`https://api.telegram.org/bot${settings.botToken}/deleteWebhook?drop_pending_updates=false`);
      const data = await res.json();
      if (data.ok) {
        await addActivityLog({
          type: 'system',
          message: 'Telegram Webhook removed. Polling mode restored.'
        }).catch(() => {});
      }
      return data;
    } catch (e: any) {
      return { ok: false, error: e.message };
    }
  }

  public async processWebhookUpdate(update: TelegramUpdate) {
    if (!update || typeof update !== 'object') return;
    this.lastPollSuccess = Date.now();
    try {
      await this.handleUpdate(update);
    } catch (err: any) {
      console.error('[BotEngine Webhook] Error handling webhook update:', err?.message || err);
    }
  }

  public async verifyToken(token?: string): Promise<{ ok: boolean; result?: any; error?: string }> {
    const settings = await getSettings();
    const botToken = token || settings.botToken;

    if (!botToken) {
      return { ok: false, error: 'Bot token is missing' };
    }

    try {
      const res = await fetch(`https://api.telegram.org/bot${botToken}/getMe`);
      const data = await res.json();
      if (data.ok) {
        this.botInfo = data.result;
        this.lastError = null;
        return { ok: true, result: data.result };
      } else {
        const desc = data.description || 'Telegram API rejected token';
        this.lastError = desc;
        return { ok: false, error: desc };
      }
    } catch (e: any) {
      this.lastError = e.message;
      return { ok: false, error: e.message };
    }
  }

  public async start(): Promise<{ success: boolean; message: string }> {
    if (this.isRunning) {
      return { success: true, message: 'Bot polling is already running' };
    }

    const test = await this.verifyToken();
    if (!test.ok) {
      return { success: false, message: `Cannot start bot: ${test.error}` };
    }

    // Delete webhook if any, to allow getUpdates
    const settings = await getSettings();
    try {
      await fetch(`https://api.telegram.org/bot${settings.botToken}/deleteWebhook?drop_pending_updates=false`);
    } catch (e) {}

    // Catch up to the latest real-time messages immediately so live users get instant responses
    try {
      const latestRes = await fetch(`https://api.telegram.org/bot${settings.botToken}/getUpdates?offset=-1&limit=1`);
      const latestData = await latestRes.json();
      if (latestData.ok && Array.isArray(latestData.result) && latestData.result.length > 0) {
        const latestId = latestData.result[0].update_id;
        if (this.pollOffset === 0 || (latestId - this.pollOffset > 20)) {
          console.log(`[BotEngine] Fast-forwarding pollOffset from ${this.pollOffset} to ${latestId} for instant real-time responses`);
          this.pollOffset = latestId;
        }
      }
    } catch (e) {}

    this.isRunning = true;
    this.abortController = new AbortController();
    this.lastPollSuccess = Date.now();
    this.pollLoop();

    // Start 24/7 Watchdog to ensure polling never dies or stalls
    if (!this.watchdogInterval) {
      this.watchdogInterval = setInterval(() => this.runWatchdog(), 20000);
    }

    await addActivityLog({
      type: 'system',
      message: `Telegram Bot @${this.botInfo?.username || 'HalpLine_bot'} started 24/7 polling.`
    });

    return { success: true, message: `Bot @${this.botInfo?.username} is active and polling updates 24/7!` };
  }

  public async stop(): Promise<{ success: boolean; message: string }> {
    if (!this.isRunning) {
      return { success: true, message: 'Bot is not running' };
    }

    this.isRunning = false;
    if (this.abortController) {
      this.abortController.abort();
      this.abortController = null;
    }

    if (this.watchdogInterval) {
      clearInterval(this.watchdogInterval);
      this.watchdogInterval = null;
    }

    await addActivityLog({
      type: 'system',
      message: 'Telegram Bot polling stopped by admin.'
    });

    return { success: true, message: 'Bot polling has been stopped' };
  }

  private async pollLoop() {
    console.log('[BotEngine] 24/7 polling loop active...');
    while (this.isRunning) {
      try {
        const settings = await getSettings();
        if (!settings.botToken) {
          await new Promise((r) => setTimeout(r, 5000));
          continue;
        }

        const url = `https://api.telegram.org/bot${settings.botToken}/getUpdates?offset=${this.pollOffset}&timeout=8&limit=100`;

        // 15-second per-request abort timeout to prevent indefinite socket hanging
        const reqController = new AbortController();
        const timeoutHandle = setTimeout(() => reqController.abort(), 15000);

        let res: Response;
        try {
          res = await fetch(url, { signal: reqController.signal });
        } finally {
          clearTimeout(timeoutHandle);
        }

        this.lastPollSuccess = Date.now();

        if (!res.ok) {
          const errText = await res.text();
          if (res.status === 409) {
            // Webhook conflict: clear webhook and wait 3s
            await fetch(`https://api.telegram.org/bot${settings.botToken}/deleteWebhook?drop_pending_updates=false`).catch(() => {});
            await new Promise((r) => setTimeout(r, 3000));
          } else {
            console.warn('[BotEngine] Telegram poll status:', res.status, errText);
            await new Promise((r) => setTimeout(r, 2000));
          }
          continue;
        }

        const data = await res.json();
        if (data.ok && Array.isArray(data.result)) {
          for (const update of data.result) {
            this.pollOffset = update.update_id + 1;
            // Process concurrently so slow AI responses never delay other incoming user messages
            this.handleUpdate(update).catch((updateErr: any) => {
              console.error('[BotEngine] Error processing update:', updateErr?.message || updateErr);
            });
          }
        }
      } catch (err: any) {
        if (!this.isRunning) break;
        if (err.name !== 'AbortError') {
          console.error('[BotEngine] Polling network warning:', err.message);
        }
        await new Promise((r) => setTimeout(r, 1000));
      }
    }
    console.log('[BotEngine] Polling loop finished.');
  }

  private async runWatchdog() {
    try {
      const settings = await getSettings().catch(() => null);
      if (!settings || !settings.botToken) return;

      // Auto-revive if polling is supposed to be active in settings but stopped
      if (settings.isPollingActive && !this.isRunning) {
        console.log('[BotEngine Watchdog] Bot is marked active but stopped. Auto-restarting 24/7 polling...');
        await this.start();
        return;
      }

      // Check for socket/network stall (>45s without polling progress)
      if (this.isRunning && (Date.now() - this.lastPollSuccess > 45000)) {
        console.warn('[BotEngine Watchdog] Polling stalled (>45s). Reviving connection...');
        this.lastPollSuccess = Date.now();
        if (this.abortController) {
          try { this.abortController.abort(); } catch (e) {}
        }
        this.abortController = new AbortController();
        this.pollLoop();
      }
    } catch (e: any) {
      console.warn('[BotEngine Watchdog] Error:', e.message);
    }
  }

  private async handleUpdate(update: TelegramUpdate) {
    if (update.message) {
      await this.handleMessage(update.message);
    }
  }

  private async handleMessage(msg: TelegramMessage) {
    if (!msg.from || msg.from.is_bot) return;

    const chatId = msg.chat.id;
    const userId = msg.from.id;
    const text = (msg.text || '').trim();

    try {
      // 1. Instantly trigger 'typing' indicator so user knows bot is already responding
      this.sendChatAction(chatId, 'typing').catch(() => {});

      // 2. Non-blocking user tracking (do NOT await, runs in background so reply is immediate)
      saveOrUpdateUser({
        id: userId,
        username: msg.from.username,
        firstName: msg.from.first_name,
        lastName: msg.from.last_name,
        status: 'active'
      }).catch(() => {});

      // 3. Fast settings retrieval from in-memory cache
      const settings = await getSettings();

      // Build inline buttons for video channels
      const inlineKeyboard: any[] = [];
      if (settings.showInlineButtons) {
        inlineKeyboard.push([
          {
            text: settings.channelButtonText || "🎬 সব ভিডিও দেখুন (FlickCove)",
            url: settings.telegramGroupLink || "https://t.me/FlickCove_Top"
          }
        ]);
        inlineKeyboard.push([
          {
            text: settings.whatsappButtonText || "📲 ব্যাকআপ চ্যানেল (WhatsApp)",
            url: settings.whatsappBackupLink || "https://whatsapp.com/channel/0029Vb7fVTzDzgT78gexpV3V"
          }
        ]);
      }

      const replyMarkup = inlineKeyboard.length > 0 ? {
        inline_keyboard: inlineKeyboard
      } : undefined;

      // Check if message is /start
      if (text.startsWith('/start')) {
        const welcomeText = settings.welcomeMessage || 
          `তুমি ভিডিও দেখতে এখানে আইছো! 🎉\n\nসব আকর্ষণীয় ও নতুন ভিডিও দেখতে নিচের বাটনে ক্লিক করে যুক্ত হোন। কোনো ভিডিও পেতে ওয়েবসাইটের ওপরে সার্চ ইঞ্জিন ব্যবহার করুন।`;

        const sendRes = await this.sendMessage({
          chat_id: chatId,
          text: welcomeText,
          reply_markup: replyMarkup
        });

        if (sendRes.ok) {
          addActivityLog({
            type: 'outgoing_msg',
            userId: userId,
            message: 'Welcome message sent (/start)'
          }).catch(() => {});
        }
        return;
      }

      // Handling normal message based on Reply Mode:
      if (settings.replyMode === 'static') {
        // Admin fixed auto-reply mode (Instant response)
        const staticReply = settings.staticReplyMessage || 
          `ওয়েবসাইটের ওপরে সার্চ ইঞ্জিন আছে, সেখানে সার্চ করলেই আশা করি ভিডিও পেয়ে যাবেন। নিচের বাটনে ক্লিক করে যুক্ত থাকুন।`;

        const sendRes = await this.sendMessage({
          chat_id: chatId,
          text: staticReply,
          reply_markup: replyMarkup
        });

        if (sendRes.ok) {
          addActivityLog({
            type: 'outgoing_msg',
            userId: userId,
            message: 'Static reply sent'
          }).catch(() => {});
        }
      } else {
        // AI Chatbot Mode (Ultra-fast Gemini with Smart Fallback)
        const aiReply = await generateAiReply(
          text, 
          msg.from.first_name
        );

        const sendRes = await this.sendMessage({
          chat_id: chatId,
          text: aiReply,
          reply_markup: replyMarkup
        });

        if (sendRes.ok) {
          addActivityLog({
            type: 'ai_generation',
            userId: userId,
            message: 'AI response sent'
          }).catch(() => {});
        }
      }
    } catch (msgErr: any) {
      console.error(`[BotEngine] Error handling message from user ${userId}:`, msgErr?.message || msgErr);
    }
  }

  public async sendChatAction(chatId: number, action: 'typing' | 'upload_photo'): Promise<void> {
    const settings = await getSettings();
    try {
      await fetch(`https://api.telegram.org/bot${settings.botToken}/sendChatAction`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, action: action })
      });
    } catch (e) {}
  }

  public async sendMessage(params: {
    chat_id: number | string;
    text: string;
    parse_mode?: string;
    reply_markup?: any;
    disable_web_page_preview?: boolean;
  }): Promise<{ ok: boolean; result?: any; error?: string; retryAfter?: number; isBlocked?: boolean }> {
    const settings = await getSettings();
    const token = settings.botToken;

    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: params.chat_id,
          text: params.text,
          parse_mode: params.parse_mode,
          reply_markup: params.reply_markup,
          disable_web_page_preview: params.disable_web_page_preview ?? false
        })
      });

      const data = await res.json();
      if (data.ok) {
        return { ok: true, result: data.result };
      } else {
        const desc = data.description || '';
        const isBlocked = desc.includes('bot was blocked by the user') || 
                          desc.includes('user is deactivated') || 
                          desc.includes('chat not found');

        if (isBlocked) {
          const numericId = typeof params.chat_id === 'number' ? params.chat_id : parseInt(String(params.chat_id), 10);
          if (!isNaN(numericId)) {
            saveOrUpdateUser({ id: numericId, status: 'blocked_bot' }).catch(() => {});
          }
          return { 
            ok: false, 
            error: desc,
            isBlocked: true
          };
        }

        // If failed due to formatting or button markup, try a plain text fallback
        if (params.parse_mode || params.reply_markup) {
          try {
            const retryRes = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                chat_id: params.chat_id,
                text: params.text,
                disable_web_page_preview: false
              })
            });
            const retryData = await retryRes.json();
            if (retryData.ok) {
              return { ok: true, result: retryData.result };
            }
          } catch (retryErr) {}
        }

        const retryAfter = data.parameters?.retry_after;
        return { 
          ok: false, 
          error: data.description || 'Unknown Telegram error',
          retryAfter: retryAfter
        };
      }
    } catch (err: any) {
      return { ok: false, error: err.message };
    }
  }

  public async sendPhoto(params: {
    chat_id: number | string;
    photo: string;
    caption?: string;
    parse_mode?: string;
    reply_markup?: any;
  }): Promise<{ ok: boolean; result?: any; error?: string; retryAfter?: number; isBlocked?: boolean }> {
    const settings = await getSettings();
    const token = settings.botToken;

    try {
      const res = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: params.chat_id,
          photo: params.photo,
          caption: params.caption,
          parse_mode: params.parse_mode,
          reply_markup: params.reply_markup
        })
      });

      const data = await res.json();
      if (data.ok) {
        return { ok: true, result: data.result };
      } else {
        const desc = data.description || '';
        const isBlocked = desc.includes('bot was blocked by the user') || 
                          desc.includes('user is deactivated') || 
                          desc.includes('chat not found');

        if (isBlocked) {
          const numericId = typeof params.chat_id === 'number' ? params.chat_id : parseInt(String(params.chat_id), 10);
          if (!isNaN(numericId)) {
            saveOrUpdateUser({ id: numericId, status: 'blocked_bot' }).catch(() => {});
          }
          return { 
            ok: false, 
            error: desc,
            isBlocked: true
          };
        }

        const retryAfter = data.parameters?.retry_after;
        return { 
          ok: false, 
          error: data.description || 'Unknown Telegram error',
          retryAfter: retryAfter
        };
      }
    } catch (err: any) {
      return { ok: false, error: err.message };
    }
  }
}

export const botEngine = new TelegramBotEngine();
