import React from 'react';
import { 
  Bot, 
  Play, 
  Square, 
  Send, 
  Users, 
  Settings, 
  MessageSquare, 
  ScrollText, 
  Radio, 
  ExternalLink,
  Sparkles,
  Database,
  Download
} from 'lucide-react';

import { SystemStatus } from '../types';

interface HeaderProps {
  status: SystemStatus | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onToggleBot: () => void;
  isToggling: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  status,
  activeTab,
  setActiveTab,
  onToggleBot,
  isToggling
}) => {
  const isRunning = status?.bot?.isRunning ?? false;
  const botUsername = status?.bot?.botInfo?.username || status?.settings?.botUsername || 'HalpLine_bot';

  const navItems = [
    { id: 'overview', label: 'ওভারভিউ', icon: Radio },
    { id: 'broadcast', label: 'ব্রডকাস্ট ইঞ্জিন', icon: Send },
    { id: 'users', label: 'ইউজার ডাটাবেজ', icon: Users },
    { id: 'settings', label: 'বট সেটিংস', icon: Settings },
    { id: 'simulator', label: 'বট টেস্ট চ্যাট', icon: MessageSquare },
    { id: 'logs', label: 'লাইভ লগস', icon: ScrollText },
  ];

  return (
    <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top bar with Branding & Bot Switch */}
        <div className="flex flex-col sm:flex-row items-center justify-between py-3.5 gap-4 border-b border-slate-800/60">
          <div className="flex items-center space-x-3.5">
            <div className="relative">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-violet-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 text-white font-bold ring-1 ring-cyan-400/30">
                <Bot className="w-6 h-6" />
              </div>
              <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full ring-2 ring-slate-900 ${
                isRunning ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
              }`} />
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-white tracking-tight">HalpLine Bot Admin</h1>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-md bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  v2.5 Pro
                </span>
                {status?.bot?.webhook?.url && (
                  <span className="px-2 py-0.5 text-[11px] font-semibold rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                    Webhook 24/7
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                <a 
                  href={`https://t.me/${botUsername}`} 
                  target="_blank" 
                  rel="noreferrer"
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono transition-colors"
                >
                  @{botUsername}
                  <ExternalLink className="w-3 h-3" />
                </a>
                <span>•</span>
                <span className="flex items-center gap-1 text-slate-300">
                  <Database className="w-3 h-3 text-amber-400" />
                  Firebase (ai-chat-bot-1d269)
                </span>
                <span>•</span>
                <span className="flex items-center gap-1 text-slate-300">
                  <Sparkles className="w-3 h-3 text-indigo-400" />
                  Gemini 3.8 Flash
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Live Bot Polling Switch Button */}
            <button
              onClick={onToggleBot}
              disabled={isToggling}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-sm transition-all shadow-md ${
                isRunning
                  ? 'bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 border border-rose-500/30'
                  : 'bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25 border border-emerald-500/30 shadow-emerald-500/10'
              } ${isToggling ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              {isRunning ? (
                <>
                  <Square className="w-4 h-4 fill-rose-500 text-rose-500" />
                  <span>বট বন্ধ করুন (Stop)</span>
                </>
              ) : (
                <>
                  <Play className="w-4 h-4 fill-emerald-500 text-emerald-500" />
                  <span>বট চালু করুন (Start)</span>
                </>
              )}
            </button>

            <a
              href={`https://t.me/${botUsername}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
            >
              <span>বট ওপেন</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>

            <a
              href="/api/download-zip"
              download="halpline-bot-source.zip"
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-indigo-600/40 to-violet-600/40 hover:from-indigo-600/60 hover:to-violet-600/60 text-indigo-200 text-xs font-semibold border border-indigo-500/40 transition-all shadow-sm"
              title="সম্পূর্ণ প্রজেক্টের ZIP ডাউনলোড করুন"
            >
              <Download className="w-3.5 h-3.5" />
              <span>কোড ZIP</span>
            </a>
          </div>
        </div>


        {/* Tab Navigation */}
        <nav className="flex space-x-1 sm:space-x-2 overflow-x-auto py-2.5 no-scrollbar">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
                {item.id === 'broadcast' && status?.broadcast?.status === 'running' && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping ml-1" />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
