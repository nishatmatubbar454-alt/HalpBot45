import React from 'react';
import { 
  Users, 
  MessageSquare, 
  Cpu, 
  Send, 
  CheckCircle2, 
  XCircle, 
  ExternalLink, 
  Copy, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Clock, 
  ArrowRight,
  Database,
  Radio
} from 'lucide-react';
import { SystemStatus, ActivityLog } from '../types';

interface OverviewTabProps {
  status: SystemStatus | null;
  logs: ActivityLog[];
  onSwitchTab: (tab: string) => void;
  onUpdateReplyMode: (mode: 'ai' | 'static') => void;
  onToggleBot: () => void;
}

export const OverviewTab: React.FC<OverviewTabProps> = ({
  status,
  logs,
  onSwitchTab,
  onUpdateReplyMode,
  onToggleBot
}) => {
  const [copiedLink, setCopiedLink] = React.useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(id);
    setTimeout(() => setCopiedLink(null), 2000);
  };

  const isRunning = status?.bot?.isRunning ?? false;
  const replyMode = status?.settings?.replyMode || 'ai';
  const tgLink = status?.settings?.telegramGroupLink || 'https://t.me/FlickCove_Top';
  const waLink = status?.settings?.whatsappBackupLink || 'https://whatsapp.com/channel/0029Vb7fVTzDzgT78gexpV3V';

  return (
    <div className="space-y-6">
      {/* Top Banner Alert if Bot is stopped */}
      {!isRunning && (
        <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-amber-200">বট বর্তমানে পজ (Stopped) অবস্থায় আছে</h4>
              <p className="text-xs text-amber-300/80">ইউজারদের মেসেজের স্বয়ংক্রিয় উত্তর দিতে এবং ব্রডকাস্ট পাঠাতে বট চালু করুন।</p>
            </div>
          </div>
          <button
            onClick={onToggleBot}
            className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md shadow-emerald-600/20"
          >
            বট চালু করুন (Start Polling)
          </button>
        </div>
      )}

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Total Users */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 relative overflow-hidden group hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">মোট বট ইউজার</span>
            <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white tracking-tight">
              {status?.stats?.totalUsers ?? 0}
            </span>
            <div className="mt-1 flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Firebase ক্লাউডে সংরক্ষিত</span>
            </div>
          </div>
        </div>

        {/* Metric 2: Active Today */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 relative overflow-hidden group hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">আজ সক্রিয় ইউজার</span>
            <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Radio className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white tracking-tight">
              {status?.stats?.activeToday ?? 0}
            </span>
            <div className="mt-1 text-xs text-slate-400">
              আজকের দিনটিতে নতুন বা সক্রিয়
            </div>
          </div>
        </div>

        {/* Metric 3: Total Messages */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 relative overflow-hidden group hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">মেসেজ আদান-প্রদান</span>
            <div className="p-2.5 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <MessageSquare className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-3xl font-extrabold text-white tracking-tight">
              {status?.stats?.totalMessages ?? 0}
            </span>
            <div className="mt-1 text-xs text-slate-400">
              মোট উত্তর ও ব্যবহারকারীর মেসেজ
            </div>
          </div>
        </div>

        {/* Metric 4: Reply Mode Status */}
        <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-5 relative overflow-hidden group hover:border-slate-700 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">বট রেসপন্স মোড</span>
            <div className={`p-2.5 rounded-xl ${
              replyMode === 'ai' 
                ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20' 
                : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
            }`}>
              {replyMode === 'ai' ? <Sparkles className="w-5 h-5" /> : <Cpu className="w-5 h-5" />}
            </div>
          </div>
          <div className="mt-3">
            <span className="text-lg font-bold text-white block truncate">
              {replyMode === 'ai' ? '🤖 Gemini AI মোড' : '📌 ফিক্সড রিপ্লাই মোড'}
            </span>
            <div className="mt-1 text-xs text-slate-400 flex items-center justify-between">
              <span>{replyMode === 'ai' ? 'স্মার্ট কথোপকথন' : 'একই নির্দিষ্ট মেসেজ'}</span>
              <button 
                onClick={() => onUpdateReplyMode(replyMode === 'ai' ? 'static' : 'ai')}
                className="text-cyan-400 hover:text-cyan-300 font-semibold underline text-[11px]"
              >
                সুইচ করুন
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content: 2 Columns */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Promotional Target & Reply Controller */}
        <div className="lg:col-span-2 space-y-6">
          {/* Video Promotion Channels Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  🎬 প্রমোশনাল ভিডিও চ্যানেল ও লিঙ্ক
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  ইউজার বটের সাথে কথা বললে বা /start দিলে সর্বদা এই লিঙ্কগুলোতে রিডাইরেক্ট করা হয়।
                </p>
              </div>
              <button
                onClick={() => onSwitchTab('settings')}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
              >
                এডিট করুন <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3.5">
              {/* Telegram Channel */}
              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center font-bold text-sm border border-blue-500/20">
                    TG
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-slate-200">মূল ভিডিও চ্যানেল (FlickCove)</div>
                    <div className="text-xs text-slate-400 font-mono">{tgLink}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => copyToClipboard(tgLink, 'tg')}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors text-xs flex items-center gap-1.5"
                    title="কপি করুন"
                  >
                    {copiedLink === 'tg' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink === 'tg' ? 'কপি হয়েছে' : 'কপি'}</span>
                  </button>
                  <a
                    href={tgLink}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white transition-colors text-xs flex items-center gap-1.5"
                  >
                    <span>ভিজিট</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* WhatsApp Channel */}
              <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold text-sm border border-emerald-500/20">
                    WA
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-slate-200">ব্যাকআপ ভিডিও চ্যানেল (WhatsApp)</div>
                    <div className="text-xs text-slate-400 font-mono truncate max-w-xs">{waLink}</div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    onClick={() => copyToClipboard(waLink, 'wa')}
                    className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors text-xs flex items-center gap-1.5"
                    title="কপি করুন"
                  >
                    {copiedLink === 'wa' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink === 'wa' ? 'কপি হয়েছে' : 'কপি'}</span>
                  </button>
                  <a
                    href={waLink}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-colors text-xs flex items-center gap-1.5"
                  >
                    <span>ভিজিট</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Mode Switcher & Explanation */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6">
            <h3 className="text-base font-bold text-white mb-2 flex items-center gap-2">
              ⚙️ ইউজার মেসেজ রেসপন্স কন্ট্রোল
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              আপনার চাহিদা অনুযায়ী অ্যাডমিন প্যানেল থেকে পছন্দ করুন ইউজার মেসেজ দিলে বট কিভাবে উত্তর দিবে:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Option 1: Gemini AI */}
              <div 
                onClick={() => onUpdateReplyMode('ai')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  replyMode === 'ai'
                    ? 'bg-purple-950/30 border-purple-500 ring-1 ring-purple-500/50 shadow-md shadow-purple-500/10'
                    : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 text-purple-300 font-semibold text-sm">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    <span>Gemini AI Chatbot</span>
                  </div>
                  {replyMode === 'ai' && (
                    <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold border border-purple-500/30">
                      সক্রিয়
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  ইউজার যাই বলুক জেমিনি এআই বুদ্ধিমানের মতো সুন্দর কথায় উত্তর দেবে এবং প্রতিটি মেসেজে ঘুরাইয়া ফিরাইয়া সুন্দর সুন্দর ভিডিওর জন্য টেলিগ্রাম ও হোয়াটসঅ্যাপ লিঙ্কে জয়েন করতে উদ্বুদ্ধ করবে।
                </p>
              </div>

              {/* Option 2: Static Auto Reply */}
              <div 
                onClick={() => onUpdateReplyMode('static')}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  replyMode === 'static'
                    ? 'bg-cyan-950/30 border-cyan-500 ring-1 ring-cyan-500/50 shadow-md shadow-cyan-500/10'
                    : 'bg-slate-950/40 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2 text-cyan-300 font-semibold text-sm">
                    <Cpu className="w-4 h-4 text-cyan-400" />
                    <span>ফিক্সড রিপ্লাই (অটো রেসপন্স)</span>
                  </div>
                  {replyMode === 'static' && (
                    <span className="px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 text-[10px] font-bold border border-cyan-500/30">
                      সক্রিয়
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  ইউজার যেকোনো মেসেজ দিলে এডমিন প্যানেল থেকে সেট করে রাখা একই নির্দিষ্ট টেক্সট ও চ্যানেলের বোতাম পাঠানো হবে।
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Bot Info & Safe Broadcast Status */}
        <div className="space-y-6">
          {/* Bot Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4 flex items-center justify-between">
              <span>টেলিগ্রাম বট স্ট্যাটাস</span>
              <span className={`flex items-center gap-1.5 text-xs font-semibold ${
                isRunning ? 'text-emerald-400' : 'text-rose-400'
              }`}>
                <span className={`w-2 h-2 rounded-full ${isRunning ? 'bg-emerald-500 animate-ping' : 'bg-rose-500'}`} />
                {isRunning ? 'অনলাইন (Polling)' : 'বন্ধ (Offline)'}
              </span>
            </h4>

            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs py-2 border-b border-slate-800/60">
                <span className="text-slate-400">বট ইউজারনেম:</span>
                <span className="text-cyan-400 font-mono font-semibold">
                  @{status?.bot?.botInfo?.username || status?.settings?.botUsername || 'HalpLine_bot'}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs py-2 border-b border-slate-800/60">
                <span className="text-slate-400">টেলিগ্রাম API কানেকশন:</span>
                <span className="flex items-center gap-1 text-emerald-400 font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  সংযুক্ত
                </span>
              </div>

              <div className="flex items-center justify-between text-xs py-2 border-b border-slate-800/60">
                <span className="text-slate-400">Firebase ডাটাবেজ:</span>
                <span className="flex items-center gap-1 text-emerald-400 font-medium">
                  <Database className="w-3.5 h-3.5" />
                  সিঙ্ক হচ্ছে
                </span>
              </div>

              <div className="flex items-center justify-between text-xs py-2">
                <span className="text-slate-400">নিরাপদ ব্রডকাস্ট ডিলে:</span>
                <span className="text-amber-400 font-semibold">
                  ৫-১০ সেকেন্ড / ইউজার
                </span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800">
              <button
                onClick={() => onSwitchTab('simulator')}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center justify-center gap-2 transition-colors border border-slate-700"
              >
                <MessageSquare className="w-4 h-4 text-cyan-400" />
                <span>বট টেস্ট সিমুলেটর খুলুন</span>
              </button>
            </div>
          </div>

          {/* Safe Broadcast Notice */}
          <div className="bg-gradient-to-br from-slate-900 to-slate-950 border border-slate-800 rounded-2xl p-5 relative overflow-hidden">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm mb-2">
              <ShieldCheck className="w-4 h-4" />
              <span>টেলিগ্রাম রুলস মেনে ব্রডকাস্ট</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              টেলিগ্রামের কঠোর স্প্যাম ও ফ্লাড রুলস মেনে এই সিস্টেমে ৫-১০ সেকেন্ড বিরতি দিয়ে একজন একজন ইউজারের কাছে মেসেজ যায়, যাতে বট একাউন্ট নিরাপদে থাকে।
            </p>
            <button
              onClick={() => onSwitchTab('broadcast')}
              className="w-full py-2 px-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition-all shadow-md shadow-cyan-600/20 flex items-center justify-center gap-2"
            >
              <Send className="w-3.5 h-3.5" />
              <span>নতুন ব্রডকাস্ট তৈরি করুন</span>
            </button>
          </div>

          {/* Quick Logs Feed */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">সাম্প্রতিক ইভেন্ট</h4>
              <button
                onClick={() => onSwitchTab('logs')}
                className="text-xs text-cyan-400 hover:underline"
              >
                সব দেখুন
              </button>
            </div>

            <div className="space-y-2 text-xs">
              {logs.slice(0, 4).map((log) => (
                <div key={log.id} className="p-2 rounded-lg bg-slate-950/60 border border-slate-800/80 flex items-start gap-2">
                  <span className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                    log.type === 'error' ? 'bg-rose-500' :
                    log.type === 'incoming_msg' ? 'bg-cyan-400' :
                    log.type === 'broadcast' ? 'bg-amber-400' : 'bg-emerald-400'
                  }`} />
                  <div className="min-w-0 flex-1">
                    <p className="text-slate-300 truncate">{log.message}</p>
                    <span className="text-[10px] text-slate-500">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                </div>
              ))}
              {logs.length === 0 && (
                <div className="text-xs text-slate-500 text-center py-4">কোন সাম্প্রতিক লগ নেই</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
